<?php

namespace App\Http\Controllers;

class BannerController extends Controller
{

}
