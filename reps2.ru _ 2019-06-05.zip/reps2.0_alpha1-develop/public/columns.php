<?php
header('Location:/redirect/columns?'.$_SERVER['QUERY_STRING']);