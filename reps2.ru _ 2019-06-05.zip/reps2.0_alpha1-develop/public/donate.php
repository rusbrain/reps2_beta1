<?php
header('Location:/redirect/home?'.$_SERVER['QUERY_STRING']);