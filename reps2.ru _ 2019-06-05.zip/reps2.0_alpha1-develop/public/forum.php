<?php
header('Location:/redirect/forum?'.$_SERVER['QUERY_STRING']);