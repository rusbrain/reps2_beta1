<?php
header('Location:/redirect/freereplays?'.$_SERVER['QUERY_STRING']);