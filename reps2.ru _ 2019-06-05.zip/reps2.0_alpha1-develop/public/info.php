<?php
header('Location:/redirect/info?'.$_SERVER['QUERY_STRING']);