<?php
header('Location:/redirect/news?'.$_SERVER['QUERY_STRING']);