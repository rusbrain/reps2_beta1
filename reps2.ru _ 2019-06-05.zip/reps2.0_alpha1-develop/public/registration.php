<?php
header('Location:/redirect/registration?'.$_SERVER['QUERY_STRING']);