<?php
header('Location:/redirect/replays?'.$_SERVER['QUERY_STRING']);