<?php
header('Location:/redirect/user?'.$_SERVER['QUERY_STRING']);